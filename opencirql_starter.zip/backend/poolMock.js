// Mock API for ledger (no keys)
const poolData = { stripe: '$0.00', solana: '1.8 SOL', payouts: [] };
function fetchPoolData() { return poolData; }
module.exports = { fetchPoolData };