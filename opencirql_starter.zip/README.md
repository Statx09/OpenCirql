# 🌐 OpenCirql

**A global open-source conversation network.**  
OpenCirql makes it easy to connect, create spaces, and have meaningful conversations — with a transparent incentive model built in.

## ✨ What is OpenCirql?
OpenCirql is an **open, community-driven platform** where anyone can:
- Join or create live voice/video spaces  
- Search profiles by interests (e.g., meditation, addiction, investing, creativity)  
- Connect globally in an open gallery of conversations  

We’re building a social layer that is **open, transparent, and rewarding by default.

... (full README content from previous draft) ...
