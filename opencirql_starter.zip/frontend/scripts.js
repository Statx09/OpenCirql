// Placeholder JS for embeds
console.log('OpenCirql frontend placeholder loaded.');